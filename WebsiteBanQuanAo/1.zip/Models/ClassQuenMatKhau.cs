﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebsiteBanQuanAo.Models
{
    public class ClassQuenMatKhau
    {
        public String EmailNhan { get; set; }
        public String ChuDe { get; set; }
        public String NoiDung { get; set; }

    }
}