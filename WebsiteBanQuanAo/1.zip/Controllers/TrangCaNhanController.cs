﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebsiteBanQuanAo.Models;

namespace WebsiteBanQuanAo.Controllers
{
    public class TrangCaNhanController : Controller
    {
        // GET: TrangCaNhan
        public ActionResult TrangCaNhan()
        {
            return View();
        }
    }
}